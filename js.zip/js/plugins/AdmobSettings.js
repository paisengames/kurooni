/*:
 * 
 * @plugindesc This provides a comment to inject the key in MV Cordova App Builder.
 * @author biud436
 * @cordova_plugin cordova-plugin-admob-free --save --variable ADMOB_APP_ID="ca-app-pub-4799738082689694~4987087584"
 * @help
 * You open this file and must change below <ADMOB_APP_ID="ca-app-pub-4799738082689694~4987087584">
 */