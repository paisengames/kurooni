//=============================================================================
// PhoneInput.js
//=============================================================================

/*:ja
 * @plugindesc ver1.00 電話のような入力画面。
 * @author まっつＵＰ
 * 
 * @param okname
 * @desc 決定音のファイル名
 * @default Decision2
 * 
 * @param okvolume
 * @desc 決定音のvolume
 * @default 90
 * 
 * @param okpitch
 * @desc 決定音のpitch
 * @default 100
 * 
 * @param okpan
 * @desc 決定音のpan
 * @default 0
 *
 * @help
 * 
 * RPGで笑顔を・・・
 * 
 * このヘルプとパラメータの説明をよくお読みになってからお使いください。
 * 
 * （プラグインコマンド）
 * command:PhoneInput
 * args:0 代入用の変数（ゲーム変数ID）
 *      1 入力文字数
 * 
 * 例：PhoneInput 1 6
 * 変数1に6文字の入力文字列を代入
 * 
 * キャンセル時は変数の代入は行われません。
 * 
 * このプラグインを利用する場合は
 * readmeなどに「まっつＵＰ」の名を入れてください。
 * また、素材のみの販売はダメです。
 * 上記以外の規約等はございません。
 * もちろんツクールMVで使用する前提です。
 * 何か不具合ありましたら気軽にどうぞ。
 *  
 * 免責事項：
 * このプラグインを利用したことによるいかなる損害も制作者は一切の責任を負いません。
 * 
 */

(function() {
    
var parameters = PluginManager.parameters('PhoneInput');
var PIokname = String(parameters['okname'] || 'Decision2');
var PIokvolume = Number(parameters['okvolume'] || 90);
var PIokpitch = Number(parameters['okpitch'] || 100);
var PIokpan = Number(parameters['okpan'] || 0);
var PIplayok = {"name":PIokname,"pan":PIokpan,"pitch":PIokpitch,"volume":PIokvolume};
var PIrealnumber = '';

var _Game_Interpreter_pluginCommand =
     Game_Interpreter.prototype.pluginCommand;
     Game_Interpreter.prototype.pluginCommand = function(command, args) {
    _Game_Interpreter_pluginCommand.call(this, command, args);
        switch(command){
            case 'PhoneInput':
            $gameMessage.PIinit(args[0], args[1]);
            SceneManager.push(Scene_PhoneInput);
            break;
        }
};

Game_Message.prototype.PIinit = function(id, digit) {
    AudioManager.loadStaticSe(PIplayok);
    PIrealnumber = '';
    this._numInputVariableId2 = Number(id || 1);
    this._numInputMaxDigits = Number(digit || 1);
};

//Scene
function Scene_PhoneInput() {
    this.initialize.call(this);
}

Scene_PhoneInput.prototype = Object.create(Scene_MenuBase.prototype);
Scene_PhoneInput.prototype.constructor = Scene_PhoneInput;

Scene_PhoneInput.prototype.initialize = function() {
    Scene_MenuBase.prototype.initialize.apply(this, arguments);
};

Scene_PhoneInput.prototype.create = function() {
    Scene_MenuBase.prototype.create.call(this);
    this.createViewNumberWindow();
    this.createPhoneNumberWindow();
};
      
Scene_PhoneInput.prototype.start = function() {
    Scene_MenuBase.prototype.start.call(this);
};
  
Scene_PhoneInput.prototype.createViewNumberWindow = function() {
    this._viewWindow = new Window_ViewNumber(0, 0); //Base
    this.addWindow(this._viewWindow);
};

Scene_PhoneInput.prototype.createPhoneNumberWindow = function() {
    this._phoneWindow = new Window_PhoneNumber(0, 0, 0, 0); //Selectable
    this._phoneWindow.y = this._viewWindow.y * 2 + this._viewWindow.height;
    this._phoneWindow.setHandler('ok', this.onphoneOk.bind(this));
    this._phoneWindow.setHandler('cancel', this.phonecancel.bind(this));
    this.addWindow(this._phoneWindow);
};

Scene_PhoneInput.prototype.onphoneOk = function() {
    var index = this._phoneWindow._index;
    if(index === 9){
        $gameVariables.setValue($gameMessage._numInputVariableId2, PIrealnumber);
        this.phonecancel();
    }else if(index === 11){
        PIrealnumber = '';
        this._phoneWindow.activate();
        this._phoneWindow.refresh();
        this._viewWindow.refresh();
    }else{
        if(index === 10){
           index = '0';
        }else{
           index = String(this._phoneWindow._list[index] || '0');
        }
        PIrealnumber = PIrealnumber + index;
        console.log(PIrealnumber)
        this._phoneWindow.activate();
        this._phoneWindow.refresh();
        this._viewWindow.refresh();
    }
};

Scene_PhoneInput.prototype.phonecancel = function() {
    $gameMessage.PIinit(0, 0);
    this.popScene();
};

//Window
function Window_ViewNumber() {
    this.initialize.apply(this, arguments);
}

Window_ViewNumber.prototype = Object.create(Window_Base.prototype);
Window_ViewNumber.prototype.constructor = Window_ViewNumber;

Window_ViewNumber.prototype.initialize = function(x, y) {
    var width = this.windowWidth();
    var height = this.windowHeight();
    var x = width;
    var y = height / 2;
    Window_Base.prototype.initialize.call(this, x, y, width, height);
    this.refresh();
};

Window_ViewNumber.prototype.lineHeight = function() {
    return 72;
};

Window_ViewNumber.prototype.standardFontSize = function() {
    return 40;
};

Window_ViewNumber.prototype.windowWidth = function() {
    return Graphics.boxWidth / 3;
};

Window_ViewNumber.prototype.windowHeight = function() {
    return this.fittingHeight(1);
};

Window_ViewNumber.prototype.refresh = function() {
    this.contents.clear();
    var ww = this.textPadding();
    this.drawText(PIrealnumber, 0, 0, this.windowWidth() * 4 / 5 + ww * 2, 'right');
};

function Window_PhoneNumber() {
    this.initialize.apply(this, arguments);
}

Window_PhoneNumber.prototype = Object.create(Window_Selectable.prototype);
Window_PhoneNumber.prototype.constructor = Window_PhoneNumber;

Window_PhoneNumber.prototype.initialize = function(x, y, width, height) {
    var width = this.windowWidth();
    var height = this.windowHeight();
    var x = Graphics.boxWidth / 2 - width / 2;
    Window_Selectable.prototype.initialize.call(this, x, y, width, height);
    this.activate();
    this.refresh();
    this.select(0);
};

Window_PhoneNumber.prototype.windowWidth = function() {
    return this.itemWidth() * this.maxCols() * 3 / 2;
};

Window_PhoneNumber.prototype.windowHeight = function() {
    return this.itemHeight() * this.numVisibleRows() * 5 / 4;
};

Window_PhoneNumber.prototype.maxCols = function() {
    return 3;
};

Window_PhoneNumber.prototype.maxItems = function() {
    return 12;
};

Window_PhoneNumber.prototype.numVisibleRows = function() {
    return 4;
};

Window_PhoneNumber.prototype.itemWidth = function() {
    return 44;
};

Window_PhoneNumber.prototype.itemHeight = function() {
    return 48;
};

Window_PhoneNumber.prototype.isCurrentItemEnabled = function() {
    return this.isEnabled(this._index);
};

Window_PhoneNumber.prototype.isEnabled = function(index) {
    if(index === 9){
        return PIrealnumber.length >= $gameMessage._numInputMaxDigits;
    }else{
        return PIrealnumber.length < $gameMessage._numInputMaxDigits;
    }
};

Window_PhoneNumber.prototype.drawItem = function(index) {
    var rect = this.itemRect(index);
    this.changePaintOpacity(this.isEnabled(index));
    this.contents.fontSize = 40;
    var text = this._list[index];
    if(index === 9) text = 'OK';
    if(index === 10) text = 0;
    if(index === 11) text = 'C';
    this.drawText(text, rect.x, rect.y, this.itemWidth(), 'center');
    this.changePaintOpacity(1);
};

Window_PhoneNumber.prototype.refresh = function() {
    this._list = [];
    for(var i = 1; i <= this.maxItems(); i++){
        this._list.push(i);
    }
    this.createContents();
    this.drawAllItems();
    if(!this.isEnabled(0)) this.select(9);
};

Window_PhoneNumber.prototype.playOkSound = function() {
    AudioManager.playStaticSe(PIplayok);
};

})();
